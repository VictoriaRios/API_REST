const express = require('express');
const cors = requiere('cors');
const db = require('./config/db.js');
const app = express();
const port = 3000;
app.use( express.json());
app.use(corse()) //permite acceso externos a express
// importamos el modelo
const Task = require('./models/tasksModel.js');


app.get('/', (req, res) => {
    res.send('<h1> API REST</h1>');
})

// Retorna todos los usuarios
app.get('/api/tasks', async (req, res) => {
    const tasks = await Task.find();
    res.json( tasks );
})

// Retorna el usuario por id
app.get('/api/tasks/:id', async (req, res) => {
    const id = req.params.id;
    console.log('id', id);
    const task = await Task.findById(id)
    res.json( task );
})

// Creamos un usuario
app.post('/api/tasks', async (req, res) => {
    const task = req.body;
    console.log(task);
    const name = task.name;
    const description = task.description;
    const state = task.state;

    const newTask = new Task({
        name: name, 
        description: description,
        state: state
    });
    await newTask.save();
    res.json( newTask );
})

// Eliminamos el usuario por id
app.delete('/api/tasks/:id', async (req, res) => {
    const id = req.params.id;
    console.log('id', id);
    const task = await Task.findByIdAndDelete(id);
    res.json( task );
})

// Actualizamos un usuario por id
app.put('/api/tasks/:id', async (req, res) => {
    const id = req.params.id;

    const task = req.body;
    console.log(task);
    const name = user.task;
    const description = task.description;
    const state = task.state;


    const newTask = await Task.findByIdAndUpdate(id, {name, description, state});

    res.json( newTask );  

})

app.listen( port, () => {
    console.log(`Servidor Web Esuchando en el puerto ${port}`);
}) 