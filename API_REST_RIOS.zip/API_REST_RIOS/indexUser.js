/* const express = require('express');
const db = require('./config/db.js');
const app = express();
const port = 3000;
app.use( express.json());

// importamos el modelo
const User = require('./models/usersModel.js');


app.get('/', (req, res) => {
    res.send('<h1> API REST</h1>');
})

// Retorna todos los usuarios
app.get('/api/users', async (req, res) => {
    const users = await User.find();
    res.json( users );
})

// Retorna el usuario por id
app.get('/api/users/:id', async (req, res) => {
    const id = req.params.id;
    console.log('id', id);
    const user = await User.findById(id)
    res.json( user );
})

// Creamos un usuario
app.post('/api/users', async (req, res) => {
    const user = req.body;
    console.log(user);
    const name = user.name;
    const email = user.email;
    const age = user.age

    const newUser = new User({
        name: name, 
        email: email,
        age: age
    });
    await newUser.save();
    res.json( newUser );
})

// Eliminamos el usuario por id
app.delete('/api/users/:id', async (req, res) => {
    const id = req.params.id;
    console.log('id', id);
    const user = await User.findByIdAndDelete(id);
    res.json( user );
})

// Actualizamos un usuario por id
app.put('/api/users/:id', async (req, res) => {
    const id = req.params.id;

    const user = req.body;
    console.log(user);
    const name = user.name;
    const email = user.email;
    const age = user.age

    const newUser = await User.findByIdAndUpdate(id, {name, email, age});

    res.json( newUser );  

})

app.listen( port, () => {
    console.log(`Servidor Web Esuchando en el puerto ${port}`);
}) */