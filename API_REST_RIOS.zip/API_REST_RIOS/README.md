# NPM
- Línea de comandos
- Repositorio
- Gestor de paquetes

# Pasos
1. Inicio un proyecto
``` bash
npm init
```