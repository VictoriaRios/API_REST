const mongoose = require('mongoose');
mongoose.connect('mongodb://127.0.0.1:27017/tasks');

const db = mongoose.connection;

db.on('error', () => {
    console.error('Error de conexión con la DB');
})

db.once('open', () => {
    console.info('Conexión la DB Ok.');
})

module.exports = db;